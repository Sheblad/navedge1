"""
AI service for damage detection and photo comparison
"""

import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim
from skimage import measure
import os
from typing import List, Dict, Any
from PIL import Image

class DamageAIService:
    def __init__(self):
        self.damage_threshold = 0.1  # Threshold for damage detection
        self.min_damage_area = 100   # Minimum area for damage detection
    
    def compare_photos(self, before_photos: List[str], after_photos: List[str]) -> Dict[str, Any]:
        """Compare before and after photos to detect damage"""
        
        if not before_photos or not after_photos:
            return {
                "damage_detected": False,
                "damage_details": {},
                "confidence": 0.0
            }
        
        # Find best matching photo pairs
        best_matches = self._find_best_matches(before_photos, after_photos)
        
        damage_results = []
        total_confidence = 0.0
        
        for before_path, after_path in best_matches:
            if os.path.exists(before_path) and os.path.exists(after_path):
                result = self._analyze_photo_pair(before_path, after_path)
                damage_results.append(result)
                total_confidence += result['confidence']
        
        # Calculate overall damage detection
        overall_damage = any(result['damage_detected'] for result in damage_results)
        avg_confidence = total_confidence / len(damage_results) if damage_results else 0.0
        
        # Compile damage details
        damage_details = {
            "total_photos_analyzed": len(damage_results),
            "damage_found_in_photos": sum(1 for r in damage_results if r['damage_detected']),
            "individual_results": damage_results,
            "overall_assessment": "Damage detected" if overall_damage else "No significant damage"
        }
        
        return {
            "damage_detected": overall_damage,
            "damage_details": damage_details,
            "confidence": avg_confidence
        }
    
    def _find_best_matches(self, before_photos: List[str], after_photos: List[str]) -> List[tuple]:
        """Find best matching photo pairs based on similarity"""
        matches = []
        
        for before_path in before_photos:
            best_match = None
            best_score = 0.0
            
            for after_path in after_photos:
                if os.path.exists(before_path) and os.path.exists(after_path):
                    # Calculate basic similarity
                    score = self._calculate_similarity(before_path, after_path)
                    if score > best_score:
                        best_score = score
                        best_match = after_path
            
            if best_match and best_score > 0.5:  # Minimum similarity threshold
                matches.append((before_path, best_match))
        
        return matches
    
    def _calculate_similarity(self, img1_path: str, img2_path: str) -> float:
        """Calculate similarity between two images"""
        try:
            # Load images
            img1 = cv2.imread(img1_path)
            img2 = cv2.imread(img2_path)
            
            if img1 is None or img2 is None:
                return 0.0
            
            # Resize to same dimensions
            img1 = cv2.resize(img1, (400, 300))
            img2 = cv2.resize(img2, (400, 300))
            
            # Convert to grayscale
            gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
            gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
            
            # Calculate SSIM
            similarity = ssim(gray1, gray2)
            return max(0.0, similarity)
            
        except Exception:
            return 0.0
    
    def _analyze_photo_pair(self, before_path: str, after_path: str) -> Dict[str, Any]:
        """Analyze a single before/after photo pair"""
        try:
            # Load images
            before_img = cv2.imread(before_path)
            after_img = cv2.imread(after_path)
            
            if before_img is None or after_img is None:
                return {
                    "damage_detected": False,
                    "confidence": 0.0,
                    "damage_areas": [],
                    "error": "Could not load images"
                }
            
            # Preprocess images
            before_processed = self._preprocess_image(before_img)
            after_processed = self._preprocess_image(after_img)
            
            # Detect differences
            differences = self._detect_differences(before_processed, after_processed)
            
            # Analyze damage
            damage_areas = self._analyze_damage_areas(differences)
            
            # Calculate confidence
            confidence = self._calculate_confidence(damage_areas)
            
            # Determine if damage is detected
            damage_detected = len(damage_areas) > 0 and confidence > 0.3
            
            return {
                "damage_detected": damage_detected,
                "confidence": confidence,
                "damage_areas": damage_areas,
                "before_photo": before_path,
                "after_photo": after_path
            }
            
        except Exception as e:
            return {
                "damage_detected": False,
                "confidence": 0.0,
                "damage_areas": [],
                "error": str(e)
            }
    
    def _preprocess_image(self, image):
        """Preprocess image for analysis"""
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Apply histogram equalization
        equalized = cv2.equalizeHist(blurred)
        
        return equalized
    
    def _detect_differences(self, before_img, after_img):
        """Detect differences between two images"""
        # Calculate absolute difference
        diff = cv2.absdiff(before_img, after_img)
        
        # Apply threshold
        _, thresh = cv2.threshold(diff, 30, 255, cv2.THRESH_BINARY)
        
        # Apply morphological operations
        kernel = np.ones((5, 5), np.uint8)
        cleaned = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        cleaned = cv2.morphologyEx(cleaned, cv2.MORPH_OPEN, kernel)
        
        return cleaned
    
    def _analyze_damage_areas(self, diff_image):
        """Analyze damage areas in difference image"""
        # Find contours
        contours, _ = cv2.findContours(diff_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        damage_areas = []
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > self.min_damage_area:
                # Get bounding rectangle
                x, y, w, h = cv2.boundingRect(contour)
                
                # Calculate damage severity
                severity = min(1.0, area / 10000)  # Normalize to 0-1
                
                damage_areas.append({
                    "area": int(area),
                    "bounding_box": {"x": int(x), "y": int(y), "width": int(w), "height": int(h)},
                    "severity": severity,
                    "type": self._classify_damage_type(contour, area)
                })
        
        return damage_areas
    
    def _classify_damage_type(self, contour, area):
        """Classify the type of damage based on contour properties"""
        # Calculate contour properties
        perimeter = cv2.arcLength(contour, True)
        
        if perimeter == 0:
            return "unknown"
        
        # Calculate circularity
        circularity = 4 * np.pi * area / (perimeter * perimeter)
        
        # Classify based on shape
        if circularity > 0.7:
            return "circular_damage"  # Possible dent
        elif circularity > 0.4:
            return "oval_damage"      # Possible scratch
        else:
            return "linear_damage"    # Possible scratch or crack
    
    def _calculate_confidence(self, damage_areas):
        """Calculate confidence score for damage detection"""
        if not damage_areas:
            return 0.0
        
        # Base confidence on number and severity of damage areas
        total_severity = sum(area['severity'] for area in damage_areas)
        num_areas = len(damage_areas)
        
        # Calculate confidence (0-1 scale)
        confidence = min(1.0, (total_severity + num_areas * 0.1) / 2.0)
        
        return confidence
